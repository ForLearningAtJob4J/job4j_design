package ru.job4j.demos;

public class Builder extends Engineer {
    int numBuildedHouses;

    public void buildNewHouse() { }
}

package ru.job4j.poly;

public class FileStore implements Store  {
    public void save(String value) {
    }

    public String[] load() {
        return new String[0];
    }
}
[![Build Status](https://travis-ci.org/ForLearningAtJob4J/job4j.svg?branch=master)](https://travis-ci.org/ForLearningAtJob4J/job4j)
[![codecov](https://codecov.io/gh/ForLearningAtJob4J/job4j/branch/master/graph/badge.svg)](https://codecov.io/gh/ForLearningAtJob4J/job4j)
# job4j

some info

I wrote here some other info

Объединение зафиксированных изменений

To test git branches

branch from IDEA

Other remark in new branch

Check from the secret place
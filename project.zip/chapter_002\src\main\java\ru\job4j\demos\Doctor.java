package ru.job4j.demos;

public class Doctor {
    String categorie;

    public void heal(Patient patient) { }
}

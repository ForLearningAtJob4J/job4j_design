package ru.job4j.oop;

public class Freshman extends Student {
}

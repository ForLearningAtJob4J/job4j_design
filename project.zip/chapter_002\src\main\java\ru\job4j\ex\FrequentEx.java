package ru.job4j.ex;

public class FrequentEx {
    public static void main(String[] args) {
        String[] shops = {"Ebay", "Amazon", "Ozon"};
        for (int index = 0; index <= shops.length; index++) {
            System.out.println(shops[index]);
        }
    }
}
package ru.job4j.demos;

public class Surgeon extends Doctor {
    boolean likeToCutPartsOfBodies;

    public void cutLeftArm(Patient patient) { }
}

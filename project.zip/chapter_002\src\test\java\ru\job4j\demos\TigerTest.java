package ru.job4j.demos;

import org.junit.Test;

public class TigerTest {
    @Test
    public void createTiger() {
        Tiger t = new Tiger("Mikle");
    }
}

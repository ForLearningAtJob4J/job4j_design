package ru.job4j.demos;

public class Engineer {
    String type;

    public void createSomethingUseful() { }
}

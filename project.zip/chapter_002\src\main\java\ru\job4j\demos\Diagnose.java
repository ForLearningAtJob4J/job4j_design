package ru.job4j.demos;

public class Diagnose {
}

package ru.job4j;

public class StudentInfo {
    public static void main(String[] args) {
        System.out.println("Sergey Sapunov");
        System.out.println("16.05.1979");
    }
}

package ru.job4j.tracker;

public class Bug extends Item {
    public Bug(String name) {
        super(name);
    }
}

package ru.job4j.oop;

public class Transport {
}

package ru.job4j.demos;

public class Dentist extends Doctor {
    String practicalArea;

    public void makeAnastesy(Patient patient) { }
}

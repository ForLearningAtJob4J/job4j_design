package ru.job4j.demos;

public class Programmer extends Engineer {
    String[] programmingLanguages;

    public void setProgrammingLanguage(String newLanguage) { }
    public void makeAllYoureTheProgrammer() { }
}

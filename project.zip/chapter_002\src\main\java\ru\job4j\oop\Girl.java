package ru.job4j.oop;

public class Girl {
    public void help(Pioneer pioneer) {
    }
}

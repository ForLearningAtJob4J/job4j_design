package ru.job4j;

public class Info {
    public static void main(String[] args) {
        System.out.println("24.02.2020");
        byte age = 12;
        boolean male = false;
        short height = 172;
        int bricks = 123456;
        long bacteries = 21474836470L;
        int distance = 1234567;
        boolean workPermit = true;
        long fileSize = 214748364722L;
    }
}

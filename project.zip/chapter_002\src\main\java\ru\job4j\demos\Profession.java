package ru.job4j.demos;

import java.util.Date;

public class Profession {
    String name, surname, education, birthday;

    public String getName() {
        return name;
    }
    public String getSurname() {
        return surname;
    }
    public String getEducation() {
        return education;
    }
    public String getBirthday() {
        return birthday;
    }
}

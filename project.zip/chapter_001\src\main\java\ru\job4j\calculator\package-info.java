/**
 * Package for calculate task.
 *
 * @author Serge Sapunov (***@yandex.ru)
 * @version $Id$
 * @since 0.1
 */
package ru.job4j.calculator;